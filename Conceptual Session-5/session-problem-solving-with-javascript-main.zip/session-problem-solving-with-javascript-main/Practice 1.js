// Print all even numbers from 1 - 20

function printEven() {
  for (let i = 1; i <= 20; i++) {
    if(i%2 == 0){
      console.log(i);
    }
  }
}

printEven();
