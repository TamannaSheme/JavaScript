function isPositive(number){
  let result;
  if(number > 0){
    result = "positive";
  } else {
    result = "negative";
  }
  return result;
}

isPositive(3)
isPositive(5)