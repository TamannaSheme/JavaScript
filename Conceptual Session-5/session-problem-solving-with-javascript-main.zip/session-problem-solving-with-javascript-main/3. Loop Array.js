let array = [3, 5, 35, 6, 33, 65];

array.length = 6;

for(let i = 0; i < array.length; i++){
  console.log(array[i]);
}

// console.log(array[6])